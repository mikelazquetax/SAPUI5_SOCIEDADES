sap.ui.define([
	'sap/base/util/deepExtend',
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (deepExtend, Controller, Fragment, Filter, FilterOperator, JSONModel, MessageToast, MessageBox, ModeloActual) {
	"use strict";

	return Controller.extend("sociedades.maz_sociedades.controller.MainView", {
	
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("MainView").attachPatternMatched(this._onRoutePatternMatched, this);
			
		},
		//Se pone esta funcion estandar porque da error la instanciacion de la vista al pulsar
		//el boton de regreso a la main view (this.getView() da undefined ). Hemos sacado la llamada a la API del OnInit y la hemos metido
		//en una funcion nueva que se llama onDataTable que se ejecuta tras renderizar la vista y tras volver de la vista secundaria de creacion 
		// mediante la funcion _onRoutePatternMatched
		_onRoutePatternMatched: function (oEvent) {
			if (oEvent.getParameter("name") === "MainView") {
				this.onDataTable();
			}
			
		},

		onAfterRendering: function () {
			this.onDataTable();
		},

		onDataTable: function () {
			var that = this;
			
			this.getView().getModel().read('/ZsociedadesSet', {
				success: function (oData, response) {
					
					//ARRAY
					var datos = oData.results;
					//creacion de la carcasa del modelo
					var oModelNew = new sap.ui.model.json.JSONModel();
					//los datos en el modelo
					oModelNew.setData(datos);
					//append del modelo a la vista
					that.getView().setModel(oModelNew, "jsonSoc");
			
					
				},
				error: function (oError) {
					
				}
				
			});
		
		
		},

			onValueHelpRequest: function (oEvent) {

			var oView = this.getView();

			if (!this._pValueHelpDialog) {
				this._pValueHelpDialog = Fragment.load({
					id: oView.getId(),
					name: "sociedades.maz_sociedades.fragment.ValueHelpDialog",
					controller: this
				}).then(function (oValueHelpDialog) {
					oView.addDependent(oValueHelpDialog);
					return oValueHelpDialog;
				});
			}
			this._pValueHelpDialog.then(function (oValueHelpDialog) {
				this._configValueHelpDialog();
				oValueHelpDialog.open();
			}.bind(this));

		},

		_configValueHelpDialog: function () {
			var sInputValue = this.getView().byId("inputVal").getValue();

			var oModel = this.getView().getModel('jsonSoc');
			var aProducts = oModel.getData();

			aProducts.forEach(function (oProduct) {
				oProduct.selected = (oProduct.ZID === sInputValue);

			});
			oModel.setProperty("/ZsociedadesSet", aProducts);
		},

		onSearch: function (evento) {
			var textoIntroducido = evento.getParameter('value');

			var filtro = new Filter("DESCRIPCION", FilterOperator.Contains, textoIntroducido);
			var binding = evento.getParameter('itemsBinding');
			binding.filter(filtro);
			evento.getParameter();

		},
		onValueHelpDialogClose: function (evento) {
			var sociedadSeleccionada = evento.getParameter('selectedItem');
			var inputSoc = this.getView().byId('inputVal');

			if (!sociedadSeleccionada) {
				inputSoc.resetProperty("value");
				return;
			}
			inputSoc.setValue(sociedadSeleccionada.getTitle());
		},

		onFiltrar: function () {
			var inputSoc = this.getView().byId('inputVal').getValue();
			var filtro = new Filter("DESCRIPCION", FilterOperator.Contains, inputSoc);
			//Obtenemos en la variable listado la tabla de clases
			var listado = this.getView().byId("tableSoc");
			var binding = listado.getBinding("rows");
			var filtros = binding.filter(filtro);

		},
		


		onSave: function (evento) {

			var updatedRecord = {
				"ZID": '',
				"DESCRIPCION": '',
				"CIF": '',
				"LAST_DATE": ''
			};

			updatedRecord.ZID = evento.getSource().getParent().getCells()[0].getText();
			updatedRecord.DESCRIPCION = evento.getSource().getParent().getCells()[1].getValue();
			updatedRecord.CIF = evento.getSource().getParent().getCells()[2].getValue();
			updatedRecord.LAST_DATE = new Date();
			var MessageTriggered;
			
			var arrayDDBB = [

				]; 
				
			var actualDDBBModel = this.getView().byId('tableSoc').getModel().oData;
			arrayDDBB.push(actualDDBBModel); 
			
			for(var i in  actualDDBBModel){
				if(arrayDDBB[0][i].ZID == updatedRecord.ZID && arrayDDBB[0][i].DESCRIPCION == updatedRecord.DESCRIPCION && 
				arrayDDBB[0][i].CIF == updatedRecord.CIF){
					MessageBox.error("Introduzca un cambio en la Descripción o el CIF");
					 MessageTriggered = 'X';
				} 
			}
			
			
			if (MessageTriggered !== 'X'){
			var path = '/ZsociedadesSet(' + updatedRecord.ZID + ')';
			this.getView().getModel().update(path, updatedRecord, {
				success: function () {
					
					MessageBox.success("Cambios Guardados");
				},
				error: function () {
					MessageBox.error("Error en el guardado de datos");
				}
			});
			
			

		}},
		
		onDelete: function(evento){
		var idBorrado =	evento.getSource().getParent().getCells()[0].getText();
		var path = '/ZsociedadesSet(' + idBorrado + ')';
		
		this.getView().getModel().remove(path,{
			method: 'DELETE',
			success: function(){
				MessageBox.success("Sociedad Borrada con Éxito");
			},
			error: function(){
				MessageBox.error("No se puede borrar la sociedad");
			}
		});
			this.onDataTable();
		},
		btonCreate: function (evento) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CreateCompany");
		}

	});
});