sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/core/UIComponent",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (Controller, History, UIComponent, MessageToast, MessageBox) {

	return Controller.extend("sociedades.maz_sociedades.controller.CreateCompany", {

		onInit: function () {

		},

		onCreate: function () {

			var newRecord = {
				"ZID": this.getView().byId('Idnew').getValue(),
				"DESCRIPCION": this.getView().byId('DescNew').getValue(),
				"CIF": this.getView().byId('CIFNew').getValue(),
				"LAST_DATE": new Date()
			};
			var path = '/ZsociedadesSet';
			var validationCIF = this.getView().getModel('validationStateCIFModel').getData().CIF;

			if (validationCIF !== 'Error') {
				this.getView().getModel().create(path, newRecord, {
					success: function () {

						MessageBox.success('Sociedad Nueva Creada con Éxito');

					},
					error: function () {
						MessageBox.error('Sociedad NO Creada. Revise sus datos');
					},

				});

			} else {
				MessageBox.error('Formato CIF Incorrecto');
			}
		},
		onBack: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = UIComponent.getRouterFor(this);
				oRouter.navTo("MainView");
			}
		},

		onChange: function (evento) {
			var valInput = this.getView().byId('Idnew').getValue();
			var checkType = isNaN(valInput);
			var lengthCIF = this.getView().byId('CIFNew').getValue().length;
			var firstToken = this.getView().byId('CIFNew').getValue().charAt(0);
			var lastToken = this.getView().byId('CIFNew').getValue().charAt(lengthCIF - 1);
			
			var middleToken = this.getView().byId('CIFNew').getValue().substring(1).slice(0,-1);
		

			if (checkType == true && valInput !== "") {
				var oView = this.getView();
				var OJSONvalidationStateModel = new sap.ui.model.json.JSONModel({
					Id: 'Error',

				});

				oView.setModel(OJSONvalidationStateModel, "validationStateModel");

			} else if (checkType == false && valInput !== "") {
				var oView = this.getView();
				var OJSONvalidationStateModel = new sap.ui.model.json.JSONModel({
					Id: 'Success',

				});

				oView.setModel(OJSONvalidationStateModel, "validationStateModel");

			}

			var checkFormat = (isNaN(firstToken) && isNaN(lastToken) && !isNaN(middleToken));

			if (lengthCIF !== 9) {
				var oView = this.getView();
				var OJSONvalidationStateCIFModel = new sap.ui.model.json.JSONModel({
					CIF: 'Error',
				});
				oView.setModel(OJSONvalidationStateCIFModel, "validationStateCIFModel");
			} else if (lengthCIF == 9 && checkFormat == true) {
				var oView = this.getView();
				var OJSONvalidationStateCIFModel = new sap.ui.model.json.JSONModel({
					CIF: 'Success',
				});
				oView.setModel(OJSONvalidationStateCIFModel, "validationStateCIFModel");
			} else if (checkFormat == false) {
				var oView = this.getView();
				var OJSONvalidationStateCIFModel = new sap.ui.model.json.JSONModel({
					CIF: 'Error'
				});
				oView.setModel(OJSONvalidationStateCIFModel, "validationStateCIFModel");

			}

		}
	});

});