sap.ui.define([
	"sociedades/maz_sociedades/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});